/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * stm32f4xx_exti.h
 * 
 * This file contains all the functions prototypes for EXTI firmware library.
 * 
 * Version V1.0.0
 * Target Processor Cortex-M4/Cortex-M3
 * 
 * Copyright (C) 2011 STMicroelectronics
 * Copyright (C) 2020 Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * stm32f4xx_exti is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version and ARM License.
 *
 * stm32f4xx_exti is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * See the ARM License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program_name.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __STM32F4xx_EXTI_H
#define __STM32F4xx_EXTI_H

#ifdef __cplusplus
    extern "C" {
#endif

#include "stm32f4xx.h"

typedef enum {
    EXTI_Mode_Interrupt = 0x00,
    EXTI_Mode_Event = 0x04
} EXTIMode_TypeDef;

#define IS_EXTI_MODE(MODE) ( \
    ((MODE) == EXTI_Mode_Interrupt) || ((MODE) == EXTI_Mode_Event) \
)

typedef enum {
    EXTI_Trigger_Rising = 0x08,
    EXTI_Trigger_Falling = 0x0C,
    EXTI_Trigger_Rising_Falling = 0x10
} EXTITrigger_TypeDef;

#define IS_EXTI_TRIGGER(TRIGGER) ( \
    ((TRIGGER) == EXTI_Trigger_Rising) || \
    ((TRIGGER) == EXTI_Trigger_Falling) || \
    ((TRIGGER) == EXTI_Trigger_Rising_Falling) \
)

typedef struct {
    uint32_t EXTI_Line; /* Specifies the EXTI lines to be enabled or disabled.
                           Can be any combination value of EXTI Line */
    EXTIMode_TypeDef EXTI_Mode; /* Specifies the mode for the EXTI lines.
                                   Parameter can be a value of
                                   EXTIMode_TypeDef */
    EXTITrigger_TypeDef EXTI_Trigger; /* Specifies the trigger signal active
                                         edge for the EXTI lines. Parameter
                                         can be value of EXTITrigger_TypeDef */
    FunctionalState EXTI_LineCmd; /* Specifies the new state of the selected
                                     EXTI lines. Parameter can be set either
                                     to ENABLE or DISABLE */
} EXTI_InitTypeDef;

#define EXTI_Line0 ((uint32_t) 0x00001) /* External interrupt line 0 */
#define EXTI_Line1 ((uint32_t) 0x00002) /* External interrupt line 1 */
#define EXTI_Line2 ((uint32_t) 0x00004) /* External interrupt line 2 */
#define EXTI_Line3 ((uint32_t) 0x00008) /* External interrupt line 3 */
#define EXTI_Line4 ((uint32_t) 0x00010) /* External interrupt line 4 */
#define EXTI_Line5 ((uint32_t) 0x00020) /* External interrupt line 5 */
#define EXTI_Line6 ((uint32_t) 0x00040) /* External interrupt line 6 */
#define EXTI_Line7 ((uint32_t) 0x00080) /* External interrupt line 7 */
#define EXTI_Line8 ((uint32_t) 0x00100) /* External interrupt line 8 */
#define EXTI_Line9 ((uint32_t) 0x00200) /* External interrupt line 9 */
#define EXTI_Line10 ((uint32_t) 0x00400) /* External interrupt line 10 */
#define EXTI_Line11 ((uint32_t) 0x00800) /* External interrupt line 11 */
#define EXTI_Line12 ((uint32_t) 0x01000) /* External interrupt line 12 */
#define EXTI_Line13 ((uint32_t) 0x02000) /* External interrupt line 13 */
#define EXTI_Line14 ((uint32_t) 0x04000) /* External interrupt line 14 */
#define EXTI_Line15 ((uint32_t) 0x08000) /* External interrupt line 15 */

/* External interrupt line 16 Connected to the PVD Output */
#define EXTI_Line16 ((uint32_t) 0x10000)

/* External interrupt line 17 Connected to the RTC Alarm event */
#define EXTI_Line17 ((uint32_t) 0x20000)

/**
 * External interrupt line 18 Connected to the USB OTG FS
 * Wakeup from suspend event.
 */
#define EXTI_Line18 ((uint32_t) 0x40000)

/* External interrupt line 19 Connected to the Ethernet Wakeup event */
#define EXTI_Line19 ((uint32_t) 0x80000)

/**
 * External interrupt line 20 Connected to the USB OTG HS
 * (configured in FS) Wakeup event.
 */
#define EXTI_Line20 ((uint32_t) 0x00100000)

/* External interrupt line 21 Connected to RTC Tamper and Time Stamp events */
#define EXTI_Line21 ((uint32_t) 0x00200000)

/* External interrupt line 22 Connected to the RTC Wakeup event */
#define EXTI_Line22 ((uint32_t) 0x00400000)

#define IS_EXTI_LINE(LINE) ( \
    (((LINE) & (uint32_t)0xFF800000) == 0x00) && ((LINE) != (uint16_t)0x00) \
)

#define IS_GET_EXTI_LINE(LINE) ( \
    ((LINE) == EXTI_Line0) || ((LINE) == EXTI_Line1) || \
    ((LINE) == EXTI_Line2) || ((LINE) == EXTI_Line3) || \
    ((LINE) == EXTI_Line4) || ((LINE) == EXTI_Line5) || \
    ((LINE) == EXTI_Line6) || ((LINE) == EXTI_Line7) || \
    ((LINE) == EXTI_Line8) || ((LINE) == EXTI_Line9) || \
    ((LINE) == EXTI_Line10) || ((LINE) == EXTI_Line11) || \
    ((LINE) == EXTI_Line12) || ((LINE) == EXTI_Line13) || \
    ((LINE) == EXTI_Line14) || ((LINE) == EXTI_Line15) || \
    ((LINE) == EXTI_Line16) || ((LINE) == EXTI_Line17) || \
    ((LINE) == EXTI_Line18) || ((LINE) == EXTI_Line19) || \
    ((LINE) == EXTI_Line20) || ((LINE) == EXTI_Line21) ||\
    ((LINE) == EXTI_Line22) \
)

void EXTI_DeInit(void);
void EXTI_Init(EXTI_InitTypeDef* EXTI_InitStruct);
void EXTI_StructInit(EXTI_InitTypeDef* EXTI_InitStruct);
void EXTI_GenerateSWInterrupt(uint32_t EXTI_Line);
FlagStatus EXTI_GetFlagStatus(uint32_t EXTI_Line);
void EXTI_ClearFlag(uint32_t EXTI_Line);
ITStatus EXTI_GetITStatus(uint32_t EXTI_Line);
void EXTI_ClearITPendingBit(uint32_t EXTI_Line);

#ifdef __cplusplus
    }
#endif

#endif

