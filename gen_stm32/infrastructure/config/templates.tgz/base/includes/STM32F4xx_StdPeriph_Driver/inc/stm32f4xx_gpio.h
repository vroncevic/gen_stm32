/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * stm32f4xx_gpio.h
 * 
 * This file contains all the functions prototypes for GPIO firmware library.
 * 
 * Version V1.0.0
 * Target Processor Cortex-M4/Cortex-M3
 * 
 * Copyright (C) 2011 STMicroelectronics
 * Copyright (C) 2020 Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * stm32f4xx_gpio is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version and ARM License.
 *
 * stm32f4xx_gpio is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * See the ARM License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program_name.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __STM32F4xx_GPIO_H
#define __STM32F4xx_GPIO_H

#ifdef __cplusplus
    extern "C" {
#endif

#include "stm32f4xx.h"

typedef enum {
    GPIO_Mode_IN = 0x00, /* GPIO Input Mode */
    GPIO_Mode_OUT = 0x01, /* GPIO Output Mode */
    GPIO_Mode_AF = 0x02, /* GPIO Alternate function Mode */
    GPIO_Mode_AN = 0x03 /* GPIO Analog Mode */
} GPIOMode_TypeDef;

typedef enum {
    GPIO_OType_PP = 0x00,
    GPIO_OType_OD = 0x01
} GPIOOType_TypeDef;

typedef enum {
    GPIO_Speed_2MHz = 0x00, /* Low speed */
    GPIO_Speed_25MHz = 0x01, /* Medium speed */
    GPIO_Speed_50MHz = 0x02, /* Fast speed */
    /* High speed on 30 pF (80 MHz Output max speed on 15 pF) */
    GPIO_Speed_100MHz = 0x03
} GPIOSpeed_TypeDef;

typedef enum {
    GPIO_PuPd_NOPULL = 0x00,
    GPIO_PuPd_UP = 0x01,
    GPIO_PuPd_DOWN = 0x02
} GPIOPuPd_TypeDef;

typedef enum {
    Bit_RESET = 0,
    Bit_SET
} BitAction;

#define GPIO_Pin_0 ((uint16_t) 0x0001) /* Pin 0 selected */
#define GPIO_Pin_1 ((uint16_t) 0x0002) /* Pin 1 selected */
#define GPIO_Pin_2 ((uint16_t) 0x0004) /* Pin 2 selected */
#define GPIO_Pin_3 ((uint16_t) 0x0008) /* Pin 3 selected */
#define GPIO_Pin_4 ((uint16_t) 0x0010) /* Pin 4 selected */
#define GPIO_Pin_5 ((uint16_t) 0x0020) /* Pin 5 selected */
#define GPIO_Pin_6 ((uint16_t) 0x0040) /* Pin 6 selected */
#define GPIO_Pin_7 ((uint16_t) 0x0080) /* Pin 7 selected */
#define GPIO_Pin_8 ((uint16_t) 0x0100) /* Pin 8 selected */
#define GPIO_Pin_9 ((uint16_t) 0x0200) /* Pin 9 selected */
#define GPIO_Pin_10 ((uint16_t) 0x0400) /* Pin 10 selected */
#define GPIO_Pin_11 ((uint16_t) 0x0800) /* Pin 11 selected */
#define GPIO_Pin_12 ((uint16_t) 0x1000) /* Pin 12 selected */
#define GPIO_Pin_13 ((uint16_t) 0x2000) /* Pin 13 selected */
#define GPIO_Pin_14 ((uint16_t) 0x4000) /* Pin 14 selected */
#define GPIO_Pin_15 ((uint16_t) 0x8000) /* Pin 15 selected */
#define GPIO_Pin_All ((uint16_t) 0xFFFF) /* All pins selected */
#define GPIO_PinSource0 ((uint8_t) 0x00)
#define GPIO_PinSource1 ((uint8_t) 0x01)
#define GPIO_PinSource2 ((uint8_t) 0x02)
#define GPIO_PinSource3 ((uint8_t) 0x03)
#define GPIO_PinSource4 ((uint8_t) 0x04)
#define GPIO_PinSource5 ((uint8_t) 0x05)
#define GPIO_PinSource6 ((uint8_t) 0x06)
#define GPIO_PinSource7 ((uint8_t) 0x07)
#define GPIO_PinSource8 ((uint8_t) 0x08)
#define GPIO_PinSource9 ((uint8_t) 0x09)
#define GPIO_PinSource10 ((uint8_t) 0x0A)
#define GPIO_PinSource11 ((uint8_t) 0x0B)
#define GPIO_PinSource12 ((uint8_t) 0x0C)
#define GPIO_PinSource13 ((uint8_t) 0x0D)
#define GPIO_PinSource14 ((uint8_t) 0x0E)
#define GPIO_PinSource15 ((uint8_t) 0x0F)

/* RTC_50Hz Alternate Function mapping */
#define GPIO_AF_RTC_50Hz ((uint8_t) 0x00)

/* MCO (MCO1 and MCO2) Alternate Function mapping */
#define GPIO_AF_MCO ((uint8_t) 0x00)

/* TAMPER (TAMPER_1 and TAMPER_2) Alternate Function mapping */
#define GPIO_AF_TAMPER ((uint8_t) 0x00)

/* SWJ (SWD and JTAG) Alternate Function mapping */
#define GPIO_AF_SWJ ((uint8_t) 0x00)

#define GPIO_AF_TRACE ((uint8_t) 0x00) /* TRACE Alternate Function mapping */
#define GPIO_AF_TIM1 ((uint8_t) 0x01) /* TIM1 Alternate Function mapping */
#define GPIO_AF_TIM2 ((uint8_t) 0x01) /* TIM2 Alternate Function mapping */
#define GPIO_AF_TIM3 ((uint8_t) 0x02) /* TIM3 Alternate Function mapping */
#define GPIO_AF_TIM4 ((uint8_t) 0x02) /* TIM4 Alternate Function mapping */
#define GPIO_AF_TIM5 ((uint8_t) 0x02) /* TIM5 Alternate Function mapping */
#define GPIO_AF_TIM8 ((uint8_t) 0x03) /* TIM8 Alternate Function mapping */
#define GPIO_AF_TIM9 ((uint8_t) 0x03) /* TIM9 Alternate Function mapping */
#define GPIO_AF_TIM10 ((uint8_t) 0x03) /* TIM10 Alternate Function mapping */
#define GPIO_AF_TIM11 ((uint8_t) 0x03) /* TIM11 Alternate Function mapping */
#define GPIO_AF_I2C1 ((uint8_t) 0x04) /* I2C1 Alternate Function mapping */
#define GPIO_AF_I2C2 ((uint8_t) 0x04) /* I2C2 Alternate Function mapping */
#define GPIO_AF_I2C3 ((uint8_t) 0x04) /* I2C3 Alternate Function mapping */
#define GPIO_AF_SPI1 ((uint8_t) 0x05) /* SPI1 Alternate Function mapping */

/* SPI2/I2S2 Alternate Function mapping */
#define GPIO_AF_SPI2 ((uint8_t) 0x05)

/* SPI3/I2S3 Alternate Function mapping */
#define GPIO_AF_SPI3 ((uint8_t) 0x06)

#define GPIO_AF_USART1 ((uint8_t) 0x07) /* USART1 Alternate Function mapping */
#define GPIO_AF_USART2 ((uint8_t) 0x07) /* USART2 Alternate Function mapping */
#define GPIO_AF_USART3 ((uint8_t) 0x07) /* USART3 Alternate Function mapping */

/* I2S3ext Alternate Function mapping */
#define GPIO_AF_I2S3ext ((uint8_t) 0x07)

#define GPIO_AF_UART4 ((uint8_t) 0x08) /* UART4 Alternate Function mapping */
#define GPIO_AF_UART5 ((uint8_t) 0x08) /* UART5 Alternate Function mapping */
#define GPIO_AF_USART6 ((uint8_t) 0x08) /* USART6 Alternate Function mapping */
#define GPIO_AF_CAN1 ((uint8_t) 0x09) /* CAN1 Alternate Function mapping */
#define GPIO_AF_CAN2 ((uint8_t) 0x09) /* CAN2 Alternate Function mapping */
#define GPIO_AF_TIM12 ((uint8_t) 0x09) /* TIM12 Alternate Function mapping */
#define GPIO_AF_TIM13 ((uint8_t) 0x09) /* TIM13 Alternate Function mapping */
#define GPIO_AF_TIM14 ((uint8_t) 0x09) /* TIM14 Alternate Function mapping */
#define GPIO_AF_OTG_FS ((uint8_t) 0xA) /* OTG_FS Alternate Function mapping */
#define GPIO_AF_OTG_HS ((uint8_t) 0xA) /* OTG_HS Alternate Function mapping */
#define GPIO_AF_ETH ((uint8_t) 0x0B) /* ETHERNET Alternate Function mapping */
#define GPIO_AF_FSMC ((uint8_t) 0xC) /* FSMC Alternate Function mapping */

/* OTG HS configured in FS, Alternate Function mapping */
#define GPIO_AF_OTG_HS_FS ((uint8_t) 0xC)

#define GPIO_AF_SDIO ((uint8_t) 0xC) /* SDIO Alternate Function mapping */
#define GPIO_AF_DCMI ((uint8_t) 0x0D) /* DCMI Alternate Function mapping */

/* EVENTOUT Alternate Function mapping */
#define GPIO_AF_EVENTOUT ((uint8_t) 0x0F)

#define GPIO_Mode_AIN GPIO_Mode_AN
#define GPIO_AF_OTG1_FS GPIO_AF_OTG_FS
#define GPIO_AF_OTG2_HS GPIO_AF_OTG_HS
#define GPIO_AF_OTG2_FS GPIO_AF_OTG_HS_FS

#define IS_GPIO_ALL_PERIPH(PERIPH) ( \
    ((PERIPH) == GPIOA) || ((PERIPH) == GPIOB) || \
    ((PERIPH) == GPIOC) || ((PERIPH) == GPIOD) || \
    ((PERIPH) == GPIOE) || ((PERIPH) == GPIOF) || \
    ((PERIPH) == GPIOG) || ((PERIPH) == GPIOH) || \
    ((PERIPH) == GPIOI) \
)

#define IS_GPIO_MODE(MODE) ( \
    ((MODE) == GPIO_Mode_IN)  || ((MODE) == GPIO_Mode_OUT) || \
    ((MODE) == GPIO_Mode_AF) || ((MODE) == GPIO_Mode_AN) \
)

#define IS_GPIO_OTYPE(OTYPE) ( \
    ((OTYPE) == GPIO_OType_PP) || ((OTYPE) == GPIO_OType_OD) \
)

#define IS_GPIO_SPEED(SPEED) ( \
    ((SPEED) == GPIO_Speed_2MHz) || ((SPEED) == GPIO_Speed_25MHz) || \
    ((SPEED) == GPIO_Speed_50MHz) || ((SPEED) == GPIO_Speed_100MHz) \
)

#define IS_GPIO_PUPD(PUPD) ( \
    ((PUPD) == GPIO_PuPd_NOPULL) || ((PUPD) == GPIO_PuPd_UP) || \
    ((PUPD) == GPIO_PuPd_DOWN) \
)

#define IS_GPIO_BIT_ACTION(ACTION) ( \
    ((ACTION) == Bit_RESET) || ((ACTION) == Bit_SET) \
)

typedef struct {
    uint32_t GPIO_Pin; /* Specifies GPIO pins to be configured.
                          Parameter can be any value of GPIO_pins_define */
    GPIOMode_TypeDef GPIO_Mode; /* Specifies operating mode for selected pins.
                                   Parameter can be a value of
                                   GPIOMode_TypeDef */
    GPIOSpeed_TypeDef GPIO_Speed; /* Specifies speed for selected pins.
                                     Parameter can be a value of
                                     GPIOSpeed_TypeDef */
    GPIOOType_TypeDef GPIO_OType; /* Specifies operating output type for
                                     selected pins. Parameter can be a value
                                     of GPIOOType_TypeDef */
    GPIOPuPd_TypeDef GPIO_PuPd; /* Specifies operating Pull-up/Pull down for
                                   selected pins. Parameter can be a value of
                                   GPIOPuPd_TypeDef */
} GPIO_InitTypeDef;

#define IS_GPIO_PIN(PIN) ( \
    (((PIN) & (uint16_t)0x00) == 0x00) && ((PIN) != (uint16_t)0x00) \
)

#define IS_GET_GPIO_PIN(PIN) ( \
    ((PIN) == GPIO_Pin_0) || ((PIN) == GPIO_Pin_1) || \
    ((PIN) == GPIO_Pin_2) || ((PIN) == GPIO_Pin_3) || \
    ((PIN) == GPIO_Pin_4) || ((PIN) == GPIO_Pin_5) || \
    ((PIN) == GPIO_Pin_6) || ((PIN) == GPIO_Pin_7) || \
    ((PIN) == GPIO_Pin_8) || ((PIN) == GPIO_Pin_9) || \
    ((PIN) == GPIO_Pin_10) || ((PIN) == GPIO_Pin_11) || \
    ((PIN) == GPIO_Pin_12) || ((PIN) == GPIO_Pin_13) || \
    ((PIN) == GPIO_Pin_14) || ((PIN) == GPIO_Pin_15) \
)

#define IS_GPIO_PIN_SOURCE(PINSOURCE) ( \
    ((PINSOURCE) == GPIO_PinSource0) || ((PINSOURCE) == GPIO_PinSource1) || \
    ((PINSOURCE) == GPIO_PinSource2) || ((PINSOURCE) == GPIO_PinSource3) || \
    ((PINSOURCE) == GPIO_PinSource4) || ((PINSOURCE) == GPIO_PinSource5) || \
    ((PINSOURCE) == GPIO_PinSource6) || ((PINSOURCE) == GPIO_PinSource7) || \
    ((PINSOURCE) == GPIO_PinSource8) || ((PINSOURCE) == GPIO_PinSource9) || \
    ((PINSOURCE) == GPIO_PinSource10) || ((PINSOURCE) == GPIO_PinSource11) || \
    ((PINSOURCE) == GPIO_PinSource12) || ((PINSOURCE) == GPIO_PinSource13) || \
    ((PINSOURCE) == GPIO_PinSource14) || ((PINSOURCE) == GPIO_PinSource15) \
)

#define IS_GPIO_AF(AF) ( \
    ((AF) == GPIO_AF_RTC_50Hz) || ((AF) == GPIO_AF_TIM14) || \
    ((AF) == GPIO_AF_MCO) || ((AF) == GPIO_AF_TAMPER) || \
    ((AF) == GPIO_AF_SWJ) || ((AF) == GPIO_AF_TRACE) || \
    ((AF) == GPIO_AF_TIM1) || ((AF) == GPIO_AF_TIM2) || \
    ((AF) == GPIO_AF_TIM3) || ((AF) == GPIO_AF_TIM4) || \
    ((AF) == GPIO_AF_TIM5) || ((AF) == GPIO_AF_TIM8) || \
    ((AF) == GPIO_AF_I2C1) || ((AF) == GPIO_AF_I2C2) || \
    ((AF) == GPIO_AF_I2C3) || ((AF) == GPIO_AF_SPI1) || \
    ((AF) == GPIO_AF_SPI2) || ((AF) == GPIO_AF_TIM13) || \
    ((AF) == GPIO_AF_SPI3) || ((AF) == GPIO_AF_TIM14) || \
    ((AF) == GPIO_AF_USART1) || ((AF) == GPIO_AF_USART2) || \
    ((AF) == GPIO_AF_USART3) || ((AF) == GPIO_AF_UART4) || \
    ((AF) == GPIO_AF_UART5) || ((AF) == GPIO_AF_USART6) || \
    ((AF) == GPIO_AF_CAN1) || ((AF) == GPIO_AF_CAN2) || \
    ((AF) == GPIO_AF_OTG_FS) || ((AF) == GPIO_AF_OTG_HS) || \
    ((AF) == GPIO_AF_ETH) || ((AF) == GPIO_AF_FSMC) || \
    ((AF) == GPIO_AF_OTG_HS_FS) || ((AF) == GPIO_AF_SDIO) || \
    ((AF) == GPIO_AF_DCMI) || ((AF) == GPIO_AF_EVENTOUT) \
)

void GPIO_DeInit(GPIO_TypeDef* GPIOx);
void GPIO_Init(GPIO_TypeDef* GPIOx, GPIO_InitTypeDef* GPIO_InitStruct);
void GPIO_StructInit(GPIO_InitTypeDef* GPIO_InitStruct);
void GPIO_PinLockConfig(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint8_t GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint16_t GPIO_ReadInputData(GPIO_TypeDef* GPIOx);
uint8_t GPIO_ReadOutputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint16_t GPIO_ReadOutputData(GPIO_TypeDef* GPIOx);
void GPIO_SetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void GPIO_ResetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void GPIO_WriteBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, BitAction BitVal);
void GPIO_Write(GPIO_TypeDef* GPIOx, uint16_t PortVal);
void GPIO_ToggleBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);

void GPIO_PinAFConfig(
    GPIO_TypeDef* GPIOx, uint16_t GPIO_PinSource, uint8_t GPIO_AF
);

#ifdef __cplusplus
    }
#endif

#endif


